#!/bin/bash
scriptDir=$(dirname "$0")
java -jar "$scriptDir/Medium.jar" 20 0
