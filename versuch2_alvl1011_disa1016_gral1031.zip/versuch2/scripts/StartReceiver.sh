#!/bin/bash
scriptDir=$(dirname "$0")
java -jar "$scriptDir/Receiver.jar"
